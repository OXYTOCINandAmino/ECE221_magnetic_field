clc
clear
close all

N = 200;
a = 0.5;
epsilon=8.854e-12;
rho = 2e-6;

y = linspace(-3,3,N);
Q = zeros(N);
Etot = zeros(N);
V = zeros(N);
E_th = zeros(N,1);
V_th = zeros(N,1);


for k = 1:N
    [Q0,Etot0,V0]=sphere_of_charge(0,y(k),0,a,N,rho);
    Q(k) = Q0;
    Etot(k) = Etot0;
    V(k) = V0;
    
    if abs(y(k)) < a
    E_th(k) = 0;
    V_th(k) = rho * a / epsilon;
    else
        E_th(k) = rho * a^2 ./ (epsilon .* y(k)^2);
        V_th(k) = rho * a^2 ./ (epsilon .* abs(y(k)));
    end
end

figure;
grid on;
hold all;
plot(y,E_th,'ro');
plot(y,Etot,'b-');
legend('Theoretical','Experimental');
title('Electrical Field');
xlabel('y(m)')
ylabel('E(V/m)')


figure;
grid on;
hold all;
plot(y,V_th,'ro');
plot(y,V,'b-');
legend('Theoretical','Experimental');
title('Electrical Potential');
xlabel('y(m)')
ylabel('V(V)')